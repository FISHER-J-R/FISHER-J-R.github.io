<?php
//Homework 3 - php practice with arrays
//Jacob Fisher
//CS385
//Spring 2024

$END_OF_SPIRAL = 111;
$to_print = array();

//need to build the table which should be a spiral of END_OF_SPIRAL size represented as a 2D array
$N_ROWS = (int) sqrt($END_OF_SPIRAL);   //we only care about the whole number of rows needed to hold all the data

for($x = 0; $x < $N_ROWS; $x++)
{
    array_push($to_print, array());
    for($j = 0; $j < $N_ROWS; $j++)
    {
        array_push($to_print[$x], 'X'); 
    }
} unset($x);

//for each row, we need N_ROWS elements



//find the position of any number by taking the same of the direction of the numbers before it
// Rs cancel Ls and Us cancel Ds
// so 11 will be the combination of the 10 directions before it or +2 rights
//spiral follows pattern RU LLDD RRRUUU LLLLDDDD RRRRRUUUUU etc so state to flip flop
$direction  = 1;

//starting position
$positionX  = (int) ($N_ROWS / 2);
$positionY  = (int) ($N_ROWS / 2);

function right( &$positionX ) { $positionX++; }
function left ( &$positionX ) { $positionX--; }
function up   ( &$positionY ) { $positionY--; }
function down ( &$positionY ) { $positionY++; }

function isPrime($number_to_check, $arrow)
{

}

$num = 1;
$i = 1;

while( $num <= $END_OF_SPIRAL)
{
    if($direction === 1)
    {
        //right
        for($x = 0; $x < $i; $x++)
        {
            $to_print[$positionY][$positionX] = $num++;
            right($positionX);
        }
        
        //up
        for($x = 0; $x < $i; $x++)
        {
            $to_print[$positionY][$positionX] = $num++;
            up($positionY);
        }

        $i++;
        $direction = $direction * -1;
    }
    else
    {
        //left
        for($x = 0; $x < $i; $x++)
        {
            $to_print[$positionY][$positionX] = $num++;
            left($positionX);
        }
        
        //down
        for($x = 0; $x < $i; $x++)
        {
            $to_print[$positionY][$positionX] = $num++;
            down($positionY);
        }

        $i++;
        $direction = $direction * -1;
    }

}

//print the whole table
echo ('<table>');
foreach($to_print as $rows)
{
    echo ('<tr>');
    foreach($rows as $val)
    {
         echo ('<td>');
         echo ($val);
         echo ('</td>');
    }
    echo ('</tr>');
}
echo ('</table');
?>