<!--
Jacob Fisher
CS385
Spring 2024
-->
<?php
class TaskInputForm
{
    public $ACTION;
    function __construct($ACTION)
    {
        $this->ACTION = $ACTION;
    }

    function __destruct()
    {
        unset( $this->ACTION);
    }

    function get_component()
    {
        echo
        "
            <form class='centered_box vertical_box' method='POST' action='$this->ACTION'>
                <p class='input_title'> CATEGORY </p>
                <input type='text' name='cat'><br>
                <p class='input_title'> TYPE </p>
                <input type='text' name='type'><br>
                <p class='input_title'> NAME </p>
                <input type='text' name='name'><br>
                <p class='input_title'> DUE </p>
                <input type='text' name='due'><br>
                <p class='input_title'> LOCATION </p>
                <input type='text' name='loc'><br>
                <br>
                <input type='submit'>
            </form>
        ";
    }
}

?>