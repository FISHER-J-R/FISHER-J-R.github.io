<!--
Jacob Fisher
CS385
Spring 2024
-->
<?php
class Task 
{
    public $category, $type, $name, $due, $loc;
    function __construct($cat, $type, $name, $due, $loc)
    {
        $this->category = $cat;
        $this->type = $type;
        $this->name = $name;
        $this->due = $due;
        $this->loc = $loc;
    }

    function __destruct()
    {
        unset( $this->category );
        unset( $this->    type );
        unset( $this->    name );
        unset( $this->     due );
        unset( $this->     loc );    
    }

    function get_component()
    {
        echo
        "
        <div class='horizontal_box task'>
            <p class='task_box task_type'> $this->type </p>
            <p class='task_box task_name'> $this->name </p>
            <p class='task_box task_due'>  $this->due  </p>
            <p class='task_box task_loc'>  $this->loc  </p>
        </div>
        ";
    }
}
?>