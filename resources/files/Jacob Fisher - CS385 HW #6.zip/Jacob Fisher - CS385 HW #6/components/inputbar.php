<!--
Jacob Fisher
CS385
Spring 2024






 << THIS COMPONENT IS GOING TO BE REPLACED >>
-->
<?php
class inputbar
{
    public $predicates; //key array of predicates with string names
    function __construct($predicates)
    {
        $this->predicates = $predicates;
    }

    function __destruct()
    {
        unset( $this->predicates );
    }

    function get_component()
    {
        //require filter sub_menu component and give it the list of predicates as a param
        echo "<div class='input_bar horizontal_box centered_box bordered_outset_box'>";
        echo "<button class='site_button'>Filter</button>";
        echo "<h1 class='input_title'>Agenda</h1>";
        echo "<button class='site_button' id='open_add_form'>Add New Task +</button>";
        echo "</div>";
    }
}

?>