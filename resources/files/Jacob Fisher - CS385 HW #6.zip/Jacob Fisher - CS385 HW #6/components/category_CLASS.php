<!--
Jacob Fisher
CS385
Spring 2024
-->
<?php

require_once "task_CLASS.php";

class Category
{
    public $tasks, $catname;
    function __construct($tasks, $catname)
    {
        $this->tasks = $tasks;
        $this->catname = $catname;
    }

    function __destruct()
    {
        unset( $this->tasks );
        unset( $this->catname );
    }

    function add_task($task)
    {
        array_push($this->tasks, $task);
    }
    function get_component()
    {
        echo
        "
            <div class='category_box vertical_box centered_box bordered_outset_box'>
            <h1 class='input_title'>$this->catname</h1>
        ";  foreach($this->tasks as $e) $e->get_component(); unset($e);
        echo
        "
            </div>
        ";
    }
}
?>