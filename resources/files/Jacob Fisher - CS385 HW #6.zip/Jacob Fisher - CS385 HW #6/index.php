<!--
Jacob Fisher
CS385
Spring 2024
-->
<!DOCTYPE html>
<html>
<!---------------------------------------------->
<head>
    <?php
        require_once "./components/category_CLASS.php";
        require_once "./components/task_CLASS.php";
        require_once "./components/taskinput_FORM_CLASS.php";

        require_once "./components/inputbar.php";

        //set the action script for adding tasks
        $TASK_ADD_ACTION = $_SERVER['PHP_SELF'];

        //set the action script for log-in
        $LOGIN_ACTION = NULL;

        $CATEGORIES = array(new Category(array(), "category"));
        $CATEGORIES[0]->add_task(new Task("category", "type", "name", "due", "location"));
    ?>

    <link rel="stylesheet" type="text/css" href="./styles.css">
</head>
<!---------------------------------------------->
<body>

    <!-- TEMPORARY CODE FOR HW #6 TO HANDLE FORM POST -->
    <?php
        if( isset($_POST) ) 
        {
            $CATEGORIES[0]->add_task(new Task(
                $_POST['cat'], 
                $_POST['type'], 
                $_POST['name'], 
                $_POST['due'], 
                $_POST['loc']
            ));
        }
    ?>
<div class="navbar centered_box horizontal_box">
    <h1 class="navbar_title"> [ insert host site navbar here ]</h1>
    <button class="site_button bordered_outset_box">log-in</button>    
</div>

    <?php
        $inputbar = new inputbar(array(0));
        $inputbar->get_component();
    ?>

<div class="page_content centered_box bordered_outset_box vertical_box">
    <div class="req_docs vertical_box">
        <p>Assumes the header of the main site</p>
        <p>2 rows in the body: 1 for filter / title / add new</p>
        <p>2 for page content</p>
        <p>blocks for categories and associated tasks</p>
        <p>tasks are horizontal: with each piece of data sectioned off</p>
    </div>
<!-- 
    In the final version, there will be an array of categories with. The cats will be generated based on input predicate selected in Filter
    foreach ( $cats as $e)
        $e->get_component();
    unset($e);
-->
    <?php

        // $CAT = new Category( array(new Task("Category", "TYPE", "NAME", "DUE", "LOCATION") ), "Category" );
        // $CAT->get_component();
        $CATEGORIES[0]->get_component();
        $form = new TaskInputForm($TASK_ADD_ACTION);
        $form->get_component();
    ?>
</body>
<!---------------------------------------------->
</html>
