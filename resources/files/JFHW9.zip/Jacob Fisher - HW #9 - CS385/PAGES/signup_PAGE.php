<?php
/*
Jacob Fisher
CS385
Spring 2024

This is a website for tracking tasks that you need to get done. It's a digital version of the organizational
system that I personally use for tracking assignments and other activities that I need to get done.

-------------------------------------Features--------------------------------------
|-> support multiple users (you can only see your own tasks, obviously)           |
|-> only show certain tasks based on user input                                   |
|-> add new tasks to the list                                                     |
|-> remove tasks from the list                                                    |
-----------------------------------------------------------------------------------
*/
?>


<!DOCTYPE html>
<html>
<!--------------------------------------------------------->
<link rel='stylesheet' href='../RESOURCES/styles.css'>
<!--------------------------------------------------------->
<body class='vertical centered'>
    <div class='vertical centered outset_bordered text_shadow content_box'>
        <h1 class='header'>SIGN-UP</h1>
        <form method='POST' action='../HANDLERS/signup_HANDLER.php' class='vertical header centered inset_bordered form_box'>
            <p>USERNAME</p>
            <input required type='text' name='username'>
            <p>PASSWORD</p>
            <input required type='password' name='password'>
            <p>RE-TYPE PASSWORD</p>
            <input required type='password' name='dpass'>
            <input type='submit'>
        </form>
    </div>
</body>
<!--------------------------------------------------------->
</html>