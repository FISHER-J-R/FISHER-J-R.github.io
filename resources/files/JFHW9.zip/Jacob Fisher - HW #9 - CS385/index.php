<?php
/*
Jacob Fisher
CS385
Spring 2024

This is a website for tracking tasks that you need to get done. It's a digital version of the organizational
system that I personally use for tracking assignments and other activities that I need to get done.

-------------------------------------Features--------------------------------------
|-> support multiple users (you can only see your own tasks, obviously)           |
|-> only show certain tasks based on user input                                   |
|-> add new tasks to the list                                                     |
|-> remove tasks from the list                                                    |
-----------------------------------------------------------------------------------
*/
?>

<?php

    require_once './COMPONENTS/task_COMPONENT.php';
    require_once './COMPONENTS/category_COMPONENT.php';
    require_once './COMPONENTS/categorylist_COMPONENT.php';
    
    if( session_status() == PHP_SESSION_NONE ) { session_start(); }
    //regenerate sesson ID
    if(!isset($_SESSION['initiated']))
    {
        session_regenerate_id();
        $_SESSION['initiated'] = true;
    }

    //TEMP NOTICE:
    //timeout code moved to login handler
?>

<!DOCTYPE html>
<html>
<!--------------------------------------------------------->
<link rel='stylesheet' href='./RESOURCES/styles.css'>
<!--------------------------------------------------------->
<body>
    <?php require_once './COMPONENTS/navbar_COMPONENT.php'; ?>
    <?php
        if( isset($_SESSION['loggedIn']))
        {
            if( isset( $_POST['delete_tID'] ) ) task_COMPONENT::REQUEST_TASK_DELETION( $_POST['delete_tID'] );
            
            $FILTER_TASK = new task_COMPONENT(0, "", "", "", "", "");

            if( isset( $_POST['filter_byTask'] ) )
            {
                $filter_cat;
                $filter_name;
                $filter_type;
                $filter_due;
                $filter_loc;

                $filter_cat  = isset( $_POST['cat'])  ? $_POST['cat']  : '';
                $filter_type = isset( $_POST['type']) ? $_POST['type'] : '';
                $filter_name = isset( $_POST['name']) ? $_POST['name'] : '';
                $filter_due  = isset( $_POST['due'])  ? $_POST['due']  : '';
                $filter_loc  = isset( $_POST['loc'])  ? $_POST['loc']  : '';
        
                $FILTER_TASK = 
                new task_COMPONENT(
                    0,
                    $filter_cat,
                    $filter_name,
                    $filter_type,
                    $filter_due,
                    $filter_loc
                );
            }

            require_once './COMPONENTS/inputbar_COMPONENT.php';

            $tasks = task_COMPONENT::REQUEST_ALL_TASKS($_SESSION['userID']);
            $catlist = new categorylist_COMPONENT();

            $catlist->add_all_tasks($tasks, $FILTER_TASK);
                $catlist->get_component();
            
            require_once './COMPONENTS/addtask_COMPONENT.php';
        }
    ?>
</body>
<!--------------------------------------------------------->
</html>