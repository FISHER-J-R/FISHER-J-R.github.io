<?php
/*
Jacob Fisher
CS385
Spring 2024
*/
?>

<?php
    function logout()
    {
        session_start();
        $_SESSION = array();
        setcookie(session_name(),"", time() - 2592000,"/");
        session_destroy();
    }
?>