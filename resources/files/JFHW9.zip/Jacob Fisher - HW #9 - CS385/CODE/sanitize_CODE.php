<?php
    function sanitizeString($string) : string
    {
        $string = stripslashes($string);
        $string = strip_tags($string);
        $string = htmlentities($string);
        return $string;
    }

    function sanitizeMySQL($pdo, $string) : string
    {
        $string = $pdo->quote($string);
        $string = sanitizeString($string);
        return $string;
    }
?>