<?php
/*
Jacob Fisher
CS385
Spring 2024
*/
?>

<?php
session_start();
require_once '../COMPONENTS/task_COMPONENT.php';
                
                $filter_cat  = isset( $_POST['cat'])  ? $_POST['cat']  : '';
                $filter_type = isset( $_POST['type']) ? $_POST['type'] : '';
                $filter_name = isset( $_POST['name']) ? $_POST['name'] : '';
                $filter_due  = isset( $_POST['due'])  ? $_POST['due']  : '';
                $filter_loc  = isset( $_POST['loc'])  ? $_POST['loc']  : '';
                
                $_SESSION['filter_byTask'] = 
                new task_COMPONENT(
                    0,
                    $filter_cat,
                    $filter_name,
                    $filter_type,
                    $filter_due,
                    $filter_loc
                );

        header( 'Location: ' . '../index.php');
        exit;
?>