<?php
/*
Jacob Fisher
CS385
Spring 2024
*/
?>

<link rel='stylesheet' href='../RESOURCES/styles.css'>

<?php
    $success = false;

    $MAX_LENGTH_INPUT = 16;
    
    if($_SERVER['REQUEST_METHOD'] === 'POST')
    if( isset($_POST['username']) && isset($_POST['password']) )
    {
        if($_POST['password'] === $_POST['dpass'])
        {
            if( strlen($_POST['username']) <= $MAX_LENGTH_INPUT && strlen( $_POST['password']) <= $MAX_LENGTH_INPUT )
            {
                $host     = 'localhost';
                $username = 'root';
                $password = '';
                $dbname   = 'Agenda';
    
                try 
                {
                    $connection = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
                    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
                    $insert_statement = $connection->prepare(
                    "INSERT INTO USER_TABLE (username, password) VALUES (:user, :hash)"
                    ); 
                    
                    $insert_statement->bindParam(":user", $user);
                    $insert_statement->bindParam(":hash", $hash);
                    
                    $user = $_POST['username'];
                    $hash = password_hash($_POST["password"], PASSWORD_DEFAULT);
                    
                    //pdo handles all the obnoxious business of making sure we dont get duplicate results
                    $connection->beginTransaction();
                        $insert_statement->execute();
                    $connection->commit();
    
                    $success = true;
                } catch(PDOException $e) 
                {
                    $connection->rollBack();
                    echo "Error: " . $e->getMessage();
                }
                
                $connection = null;
            } 
        }
    }

    
    if( $success )
    {
        header( 'Location: ' . '../PAGES/login_PAGE.php');
        exit;
    }
    else
    {
        header( 'Location: ' . '../PAGES/signup_PAGE.php');
        exit;
    }

?>