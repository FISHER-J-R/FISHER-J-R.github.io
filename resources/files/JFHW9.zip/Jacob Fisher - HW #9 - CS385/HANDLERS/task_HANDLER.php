<?php
/*
Jacob Fisher
CS385
Spring 2024
*/
?>

<?php
session_start();
require_once '../COMPONENTS/task_COMPONENT.php';
require_once '../CODE/sanitize_CODE.php';

        if( isset($_POST['cat']) && 
            isset($_POST['type']) &&
            isset($_POST['name']) &&
            isset($_POST['due']) &&
            isset($_POST['location'])
        )
        {
            if( strlen($_POST['cat']) < 16 &&
                strlen($_POST['type']) < 16 &&
                strlen($_POST['name']) < 16 &&
                strlen($_POST['due']) < 16 &&
                strlen($_POST['location']) < 16 
            )
            {
                $task = new task_COMPONENT(NULL,
                    $_POST['cat'],
                    $_POST['type'],
                    $_POST['name'],
                    $_POST['due'],
                    $_POST['location']
                );

                $task->post_task();
            }
        }

        header( 'Location: ' . '../index.php');
        exit;
?>