<?php
/*
Jacob Fisher
CS385
Spring 2024
*/
?>

<?php

function printUsername() {
    if(isset($_SESSION['username']))
        $username = $_SESSION['username'];

    if( $username[strlen($username)-1] == 's')
       echo $username."' ";
    else
       echo $username."'s ";
}
?>

<div class='horizontal centered spaced'>
    <button id='filterBtn' class='inputbar_button outset_bordered text text_shadow'> Filter </button>
    <?php require_once './COMPONENTS/filterTask_COMPONENT.php' ?>
    <h1 class='text_shadow header'> <?php printUsername(); ?> Agenda </h1>
    <button id='addTaskBtn' class='inputbar_button outset_bordered text text_shadow'> Add Task </button>
    <?php require_once './COMPONENTS/addTask_COMPONENT.php' ?>
</div>