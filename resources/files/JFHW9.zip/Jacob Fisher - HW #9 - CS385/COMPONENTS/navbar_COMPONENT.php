<?php
/*
Jacob Fisher
CS385
Spring 2024
*/
?>

<?php 
if( session_status() == PHP_SESSION_NONE ) {
    session_start();
} 
?>

<div class='navbar horizontal spaced outset_bordered'>
    <h1 class='text_shadow header'> NAVBAR </h1> 
    <div class='horizontal'>
    
    <?php
        if (isset($_SESSION["loggedIn"]) && isset( $_SESSION["username"])) 
        {
            echo
            "
            <div class='vertical centered'>
                <p> welcome, " . $_SESSION['username'] . " </p>
                <form method='POST' action='./HANDLERS/logout_HANDLER.php'>
                    <input type='hidden' name='logout' value='logout'>
                    <input type='submit' value='logout'>
                </form>
            </div>
            ";
        }
        else
        {
            echo
            "
            <a href='./PAGES/signup_PAGE.php'>
                <button class='site_button outset_bordered text_shadow'>SIGN-UP</button>
            </a>

            <a href='./PAGES/login_PAGE.php'>
                <button class='site_button outset_bordered text_shadow'>LOG-IN</button>
            </a>
            ";
        }
    ?>


    </div>
</div>