<?php
/*
Jacob Fisher
CS385
Spring 2024
*/
?>

<?php

class task_COMPONENT
{
    public $ID, $CAT, $TYPE, $NAME, $DUE, $LOC;
    public static function REQUEST_ALL_TASKS($userID): array
    {
        $host     = 'localhost';
        $username = 'root';
        $password = '';
        $dbname   = 'Agenda';

        $connection = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
         
        $query = $connection->prepare(
            "
                SELECT * FROM TASK_TABLE WHERE userID = $userID
            "
        ); $query->execute();
        
        $returnArray = array();

        $result = $query->fetch(PDO::FETCH_ASSOC);
        while( $result )
        {
            array_push( $returnArray, new task_COMPONENT(
                $result['taskID'],
                $result['task_cat'],
                $result['task_type'],
                $result['task_name'],
                $result['task_due'],
                $result['task_loc']
            ));

            $result = $query->fetch(PDO::FETCH_ASSOC);
        }
        
        return $returnArray;
    }

    public static function REQUEST_TASK_DELETION($taskID): bool
    {

        $result = false;
        try
        {
            $host     = 'localhost';
            $username = 'root';
            $password = '';
            $dbname   = 'Agenda';

            $connection = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
            $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $delete = $connection->prepare(
                "
                    DELETE FROM TASK_TABLE WHERE taskID = :tID
                "
            ); $delete->bindParam(":tID", $taskID);
            $result = $delete->execute();

            $connection = NULL;
        }
        catch(Exception $e)
        {
            echo "failure: ".$e->getMessage();
        }

        return $result;
    }

    public static function COMPARE_TASK($task1, $task2) : bool
    {
        $result = true;

        if( !str_contains($task1->CAT, $task2->CAT)   ) $result = false;
        if( !str_contains($task1->TYPE, $task2->TYPE) ) $result = false;
        if( !str_contains($task1->NAME, $task2->NAME) ) $result = false;
        if( !str_contains($task1->DUE, $task2->DUE)   ) $result = false;
        if( !str_contains($task1->LOC, $task2->LOC)   ) $result = false;

        return $result;
    }

    function __construct($ID, $CAT, $TYPE, $NAME, $DUE, $LOC)
    {
        $this->ID   = str_replace(['"',"'"], "", $ID);
        $this->CAT  = str_replace(['"',"'"], "", $CAT);
        $this->TYPE = str_replace(['"',"'"], "", $TYPE); 
        $this->NAME = str_replace(['"',"'"], "", $NAME);
        $this->DUE  = str_replace(['"',"'"], "", $DUE);
        $this->LOC  = str_replace(['"',"'"], "", $LOC);
    }
    
    function __destruct()
    {
        unset($this->ID);
        unset($this->CAT);
        unset($this->TYPE);
        unset($this->NAME);
        unset($this->DUE);
        unset($this->LOC);
    }
    
    function get_component()
    {
        echo
        "
        <div class='horizontal task centered'>
            <p class='task_box task_type'> $this->TYPE </p>
            <p class='task_box task_name'> $this->NAME </p>
            <p class='task_box task_due'>  $this->DUE  </p>
            <p class='task_box task_loc'>  $this->LOC  </p>
            <form method='POST' action='".$_SERVER['PHP_SELF']."' class='centered task_box'>
                <input type='hidden' name='delete_tID' value='$this->ID'>
                <input class='task_delete_button' type='submit' value='delete task'>
            </form>
        </div>
        ";
    }
    
    function post_task()
    {
        try
        {
            $host =     'localhost';
            $username = 'root';
            $password = '';
            $dbname   = 'Agenda';

            $connection = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
            $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            require_once "../CODE/sanitize_CODE.php";

            $post_task = $connection->prepare(
                "
                    INSERT INTO TASK_TABLE (userID, task_cat, task_type, task_name, task_due, task_loc) VALUES
                    (:userID, :cat, :type, :name, :due, :loc)
                "
            );
            $post_task->bindParam(":userID" , $_SESSION['userID']                     );
            $post_task->bindParam(":cat"    , sanitizeMySQL($connection, $this->CAT)  );
            $post_task->bindParam(":type"   , sanitizeMySQL($connection, $this->TYPE) );
            $post_task->bindParam(":name"   , sanitizeMySQL($connection, $this->NAME) );
            $post_task->bindParam(":due"    , sanitizeMySQL($connection, $this->DUE)  );
            $post_task->bindParam(":loc"    , sanitizeMySQL($connection, $this->LOC)  );
            $post_task->execute();

            $connection = NULL;
        }
        catch(Exception $e)
        {
            echo "failure: ".$e->getMessage();
        }
    }
}
?>