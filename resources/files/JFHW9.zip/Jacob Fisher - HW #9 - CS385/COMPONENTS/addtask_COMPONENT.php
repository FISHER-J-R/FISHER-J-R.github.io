<?php
/*
Jacob Fisher
CS385
Spring 2024
*/
?>
<div id="addTaskForm" class="modal">
<!-- Modal content -->
<div class="modal-content outset_bordered">
    <div class="outset_bordered centered form_box">
        <span class="close">&times;</span>
        <h1 class='text_shadow header'>Add New Task</h2>
    </div>
  <div class="modal-body">
    <div class='outset_bordered text_shadow content_box vertical'>
        <form method="POST" action="./HANDLERS/task_HANDLER.php" class='vertical header centered inset_bordered form_box'>
            <p>category</p>
            <input type='text' name='cat'>
            <p>type</p>
            <input type='text' name='type'>
            <p>name</p>
            <input type='text' name='name'>
            <p>due</p>
            <input type='text' name='due'>
            <p>location</p>
            <input type='text' name='location'>
            <input type='submit'>
        </form>
    </div>

        </div>
    </div>
</div>

<script src="./RESOURCES/SCRIPTS/addTaskModal.js"></script>