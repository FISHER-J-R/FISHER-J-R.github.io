<?php
//this is bad, but for now we're going to directly access $cat
$GLOBALS['cat']->add_task(
    new task(
       $_POST["cat"], 
       $_POST["type"], 
       $_POST["name"], 
       $_POST["due"], 
       $_POST["loc"]
    )
);

?>