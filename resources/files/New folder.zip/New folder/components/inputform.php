<!--
Jacob Fisher
CS385
Spring 2024
-->
<?php
class inputForm
{
    function __construct()
    {
    }

    function __destruct()
    {
    }

    function get_component()
    {
        echo "<form method='POST' action=' $_SERVER['PHP_SELF'] '>";
            echo "<div class='vertical_box centered_box'>";
                echo "<h1 class='input_title'>Add Task</h1>";
                echo "<div class='horizontal_box input_bar'>";

                    echo "<p class='input_title'>Category:</p>";
                    echo "<input type='text' id='cat' name='cat'>";

                echo "</div>";
                echo "<div class='horizontal_box'>";

                    echo "<p class='input_title'>Type:</p>";
                    echo "<input type='text' id='type' name='type'>";
                
                echo "</div>";
                echo "<div class='horizontal_box'>";

                    echo "<p class='input_title'>Name:</p>";
                    echo "<input type='text' id='name' name='name'>";

                echo "</div>";
                echo "<div class='horizontal_box'>";
                
                    echo "<p class='input_title'>Due:</p>";
                    echo "<input type='text' id='due' name='due'>";
                    
                echo "</div>";
                echo "<div class='horizontal_box'>";
                    
                    echo "<p class='input_title'>Location:</p>";
                    echo "<input type='text' id='loc' name='loc'>";

                echo "</div>";
                echo "<input type='submit'>";
            echo "</div>";
        echo "</form>";

        <?php

        $CAT->add_task(
            new task(
               $_POST["cat"], 
               $_POST["type"], 
               $_POST["name"], 
               $_POST["due"], 
               $_POST["loc"]
            )
        );
        ?>
    }
}

?>