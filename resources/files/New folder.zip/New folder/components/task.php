<!--
Jacob Fisher
CS385
Spring 2024
-->
<?php
class Task 
{
    public $category, $type, $name, $due, $location;
    function __construct($cat, $type, $name, $due, $loc)
    {
        $this->category = $cat;
        $this->type = $type;
        $this->name = $name;
        $this->due = $due;
        $this->location = $loc;
    }

    function __destruct()
    {
        unset( $this->category );
        unset( $this->    type );
        unset( $this->    name );
        unset( $this->     due );
        unset( $this->location );    
    }

    function get_component()
    {
        echo "<div class= 'task horizontal_box'>";
  
        echo "<p   class= 'task_box task_type'>     [ $this->type ]     </p>";
        echo "<p   class= 'task_box task_name'>     [ $this->name ]     </p>";
        echo "<p   class= 'task_box task_due'>      [ $this->due ]      </p>";
        echo "<p   class= 'task_box task_location'> [ $this->location ] </p>";
  
        echo "</div>";
    }
}
?>