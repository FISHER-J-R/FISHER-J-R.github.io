document.addEventListener('DOMContentLoaded', event => {

document.getElementById('task_add_button').onclick = () => 
{
    var form = document.getElementById('task_form');
    if( form.classList.contains('hidden') )
    {
        form.classList.remove('hidden');
        form.classList.add('vertical');
    }
    else
    {
        form.classList.add('hidden');
        form.classList.remove('vertical');
    }
};

});
