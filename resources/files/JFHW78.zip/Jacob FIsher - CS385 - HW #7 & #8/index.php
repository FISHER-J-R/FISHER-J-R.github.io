<?php
/*
Jacob Fisher
CS385
Spring 2024

This is a website for tracking tasks that you need to get done. It's a digital version of the organizational
system that I personally use for tracking assignments and other activities that I need to get done.

-------------------------------------Features--------------------------------------
|-> support multiple users (you can only see your own tasks, obviously)           |
|-> only show certain tasks based on user input                                   |
|-> add new tasks to the list                                                     |
|-> remove tasks from the list                                                    |
-----------------------------------------------------------------------------------
*/
?>

<?php
if( session_status() == PHP_SESSION_NONE ) {
    session_start();
}

    if( isset($_SESSION['timestamp']))
    {
        if( time() - $_SESSION['timestamp'] > 60 * 60)
        {
            require_once './CODE/logout_CODE.php';
            logout();
        }
    }
?>

<!DOCTYPE html>
<html>
<!--------------------------------------------------------->
<link rel='stylesheet' href='./RESOURCES/styles.css'>
<!--------------------------------------------------------->
<body>
    <?php require_once './COMPONENTS/navbar_COMPONENT.php'; ?>
    <?php
        if( isset($_SESSION['loggedIn']))
        {
            require_once './COMPONENTS/task_COMPONENT.php';
            require_once './COMPONENTS/category_COMPONENT.php';

            $task = new task_COMPONENT(null, "cat", "type", "name", "due", "loc");

            // for($i = 0; $i < 10; $i++)
            //     $task->post_task();
            // unset($i);

            $tasks = task_COMPONENT::REQUEST_ALL_TASKS($_SESSION['userID']);

            foreach($tasks as $task)
                $task->get_component();
            unset($task);
            
            require_once './COMPONENTS/addtask_COMPONENT.php';
        }
    ?>

    <script src='./RESOURCES/SCRIPTS/activateForm.js'></script>
    <button id="task_add_button"> Open Form </button>
</body>
<!--------------------------------------------------------->
</html>