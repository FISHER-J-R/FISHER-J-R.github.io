<?php
/*
Jacob Fisher
CS385
Spring 2024
*/
?>

<?php
    session_start();
    if($_POST['logout'] == true)
    {
        require_once '../CODE/logout_CODE.php';
        logout();
    }

    header( 'Location: ' . '../index.php');
    exit;
?>