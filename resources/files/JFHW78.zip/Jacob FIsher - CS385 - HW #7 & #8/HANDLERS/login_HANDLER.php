<?php
/*
Jacob Fisher
CS385
Spring 2024
*/
?>

<link rel='stylesheet' href='../RESOURCES/styles.css'>

<?php
$MAX_LENGTH_INPUT = 16;
$success = false;

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    if( isset($_POST['username']) && isset($_POST['password']) )
    {
        if(strlen($_POST['username']) <= $MAX_LENGTH_INPUT && strlen($_POST['password']) <= $MAX_LENGTH_INPUT)
        {
            try
            {
                $host =     'localhost';
                $username = 'root';
                $password = '';
                $dbname   = 'Agenda';
    
                $connection = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
                $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
                $check_user = $connection->prepare(
                "
                    SELECT * FROM USER_TABLE WHERE username = :user;
                "
                ); $check_user->bindParam(":user", $user);
                $user = $_POST['username'];

                $check_user->execute();
                
                $result = $check_user->fetch(PDO::FETCH_ASSOC);
                if( isset( $result["password"] ))
                {
                    $verified = password_verify($_POST['password'], $result['password']);
                    if( $verified )
                    {
                        session_start();
                        $_SESSION['username'] = $result['username'];
                        $_SESSION['userID']   = $result['userID'];
                        $_SESSION['loggedIn'] = true;
                        $_SESSION['timestamp'] = time();
                        $success = true;
                    }
                }
            }  
            catch(Exception $e)
            {
                echo 'Failed: '. $e->getMessage();
            }
        }
    }


    if( $success )
    {
        header( 'Location: ' . '../index.php');
        exit;
    }
    else
    {
        header( 'Location: ' . '../PAGES/login_PAGE.php');
        exit;
    }
}
?>

