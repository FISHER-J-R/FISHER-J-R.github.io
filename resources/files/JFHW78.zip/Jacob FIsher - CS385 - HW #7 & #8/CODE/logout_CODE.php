<?php
/*
Jacob Fisher
CS385
Spring 2024
*/
?>

<?php
    function logout()
    {
        unset($_SESSION['username']);
        unset($_SESSION['userID']);
        unset($_SESSION['loggedIn']);
        unset($_SESSION['timestamp']);
        unset($_SESSION['PDO']);
        session_destroy();
    }
?>