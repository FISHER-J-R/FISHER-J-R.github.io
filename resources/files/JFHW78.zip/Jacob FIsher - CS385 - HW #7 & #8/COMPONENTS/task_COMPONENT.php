<?php
/*
Jacob Fisher
CS385
Spring 2024
*/
?>

<?php

class task_COMPONENT
{
    public $ID, $CAT, $TYPE, $NAME, $DUE, $LOC;
    public static function REQUEST_ALL_TASKS($userID): array
    {
        $host     = 'localhost';
        $username = 'root';
        $password = '';
        $dbname   = 'Agenda';

        $connection = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
         
        $query = $connection->prepare(
            "
                SELECT * FROM TASK_TABLE WHERE userID = $userID
            "
        ); $query->execute();
        
        $returnArray = array();

        $result = $query->fetch(PDO::FETCH_ASSOC);
        while( $result )
        {
            array_push( $returnArray, new task_COMPONENT(
                $result['taskID'],
                $result['task_cat'],
                $result['task_type'],
                $result['task_name'],
                $result['task_due'],
                $result['task_loc']
            ));

            $result = $query->fetch(PDO::FETCH_ASSOC);
        }

        return $returnArray;
    }
    function __construct($ID, $CAT, $TYPE, $NAME, $DUE, $LOC)
    {
        $this->ID   = $ID;
        $this->CAT  = $CAT;
        $this->TYPE = $TYPE;    
        $this->NAME = $NAME;
        $this->DUE  = $DUE;
        $this->LOC  = $LOC;
    }
    
    function __destruct()
    {
        unset($this->ID);
        unset($this->CAT);
        unset($this->TYPE);
        unset($this->NAME);
        unset($this->DUE);
        unset($this->LOC);
    }
    
    function get_component()
    {
        echo
        "
        <div class='horizontal task'>
            <p class='task_box task_type'> $this->TYPE </p>
            <p class='task_box task_name'> $this->NAME </p>
            <p class='task_box task_due'>  $this->DUE  </p>
            <p class='task_box task_loc'>  $this->LOC  </p>
        </div>
        ";
    }
    
    function post_task()
    {
        try
        {
            $host =     'localhost';
            $username = 'root';
            $password = '';
            $dbname   = 'Agenda';

            $connection = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
            $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $post_task = $connection->prepare(
                "
                    INSERT INTO TASK_TABLE (userID, task_cat, task_type, task_name, task_due, task_loc) VALUES
                    (:userID, :cat, :type, :name, :due, :loc)
                "
            );
            $post_task->bindParam(":userID" , $_SESSION['userID']);
            $post_task->bindParam(":cat"    , $this->CAT         );
            $post_task->bindParam(":type"   , $this->TYPE        );
            $post_task->bindParam(":name"   , $this->NAME        );
            $post_task->bindParam(":due"    , $this->DUE         );
            $post_task->bindParam(":loc"    , $this->LOC         );
            $post_task->execute();

            $connection = NULL;
        }
        catch(Exception $e)
        {
            echo "failure: ".$e->getMessage();
        }
    }

    function request_task_deletion(): bool
    {

        $result = false;
        try
        {
            $host =     'localhost';
            $username = 'root';
            $password = '';
            $dbname   = 'Agenda';

            $connection = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
            $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $delete =$connection->prepare(
                "
                    DELETE FROM TASK_TABLE WHERE taskID = :tID
                "
            ); $delete->bindParam(":tID", $this->ID);
            $result = $delete->execute();

            $connection = NULL;
        }
        catch(Exception $e)
        {
            echo "failure: ".$e->getMessage();
        }

        return $result;
    }
}
?>