<?php
/*
Jacob Fisher
CS385
Spring 2024
*/
?>
<div id='task_form' class='vertical centered outset_bordered text_shadow content_box'>
    <form method="POST" action="./HANDLERS/task_HANDLER.php" class='vertical header centered inset_bordered form_box'>
        <p>category</p>
        <input type='text' name='cat'>
        <p>type</p>
        <input type='text' name='type'>
        <p>name</p>
        <input type='text' name='name'>
        <p>due</p>
        <input type='text' name='due'>
        <p>location</p>
        <input type='text' name='location'>
        <input type='submit'>
    </form>
</div>
