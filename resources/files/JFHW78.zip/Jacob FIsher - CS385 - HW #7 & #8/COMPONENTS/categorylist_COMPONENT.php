<?php
/*
Jacob Fisher
CS385
Spring 2024
*/
?>

<?php
class catlist_COMPONENT
{
    public $catlist;
    public function __construct()
    {
        $this->catlist = array();
    }

    public function __destruct()
    {
       unset($this->catlist);
    }

    function get_component()
    {
        echo
        "
            <div class='vertical centered outset_bordered'>
        ";

        foreach( $this->catlist as $cat )
        $cat->get_component();

        echo
        "
            </div>
        ";
    }

    function add_cat($category)
    {
        if( !$this->contains_cat( $category))
            $this->catlist[$category->catname] = $category;
    }

    function contains_cat($category)
    {
        return isset($this->catlist[$category->catname]);
    }
}

?>