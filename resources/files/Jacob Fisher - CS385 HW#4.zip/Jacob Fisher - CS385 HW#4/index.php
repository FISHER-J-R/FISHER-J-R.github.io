<!--
Jacob Fisher
CS385
Spring 2024
-->

<?php

?>

<!DOCTYPE html>
<html>
<!---------------------------------------------->
<head>
    <link rel="stylesheet" type="text/css" href="./styles.css">
</head>
<!---------------------------------------------->
<body>
<div class="navbar centered_box horizontal_box">
    <h1 class="navbar_title"> [ insert host site navbar here ]</h1>
    <button class="site_button bordered_outset_box">log-in</button>    
</div>

    <?php
        require_once "./components/inputbar.php";
        $inputbar = new inputbar(array(0));
        $inputbar->get_component();
    ?>

<div class="page_content centered_box bordered_outset_box vertical_box">
    <div class="req_docs vertical_box">
        <p>Assumes the header of the main site</p>
        <p>2 rows in the body: 1 for filter / title / add new</p>
        <p>2 for page content</p>
        <p>blocks for categories and associated tasks</p>
        <p>tasks are horizontal: with each piece of data sectioned off</p>
    </div>
<!-- 
    In the final version, there will be an array of categories with. The cats will be generated based on input predicate selected in Filter
    foreach ( $cats as $e)
        $e->get_component();
    unset($e);
-->
    <?php
        require_once "components/category.php";
        $CAT = new Category( array(new Task("Category", "TYPE", "NAME", "DUE", "LOCATION") ), "Category" );
        $CAT->get_component();
    ?>
</body>
<!---------------------------------------------->
</html>
